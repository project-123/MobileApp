package com.cg.mpa.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.service.IMobileService;
import com.cg.mpa.service.MobileServiceImpl;

/**
 * Servlet implementation class MobileController
 */
@WebServlet(urlPatterns = {"/home","/Buy","/purchase"})
public class MobileController extends HttpServlet {
private static final long serialVersionUID = 1L;
       
    
    public MobileController() {
        super();
    }

	
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String path=request.getServletPath();
		String url="";
		IMobileService mser=new MobileServiceImpl();
		System.out.println(path);
		
		try {
			switch(path)
			{
			case "/home":
				List<Mobile> mlist=mser.getMobiles();
				request.setAttribute("mlist", mlist);
				url="Home.jsp";
				break ;
				
			case "/Buy":
				int mid=Integer.parseInt(request.getParameter("mid"));
				HttpSession sess=request.getSession(true);
				sess.setAttribute("mid", mid);
				url="Insert.jsp";
				break ;
				
			case "/purchase":
				PurchaseDetails pdeDetails=new PurchaseDetails();
				pdeDetails.setCname(request.getParameter("cname"));
				pdeDetails.setMailid(request.getParameter("mailid"));
				pdeDetails.setPhoneno(request.getParameter("phoneno"));
				String dateStr=request.getParameter("pdate");
				DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
				
				pdeDetails.setPurchaseDate(LocalDate.parse(dateStr,dtf));
				
				sess=request.getSession(false);
				pdeDetails.setMobileid((Integer)sess.getAttribute("mid"));
				
				int pid=mser.insertPurchase(pdeDetails);
				
				request.setAttribute("pdeDetails", pdeDetails);
				url="Success.jsp";
				break ;
				
				
			}
		} catch (MobileException e) {
			request.setAttribute("error", e.getMessage());
			url="Error.jsp";
		}
		catch (Exception e)
		{
			request.setAttribute("error", e.getMessage());
			url="Error.jsp";
			
		}
		
		RequestDispatcher disp=request.getRequestDispatcher(url);
		disp.forward(request, response);
		
	}


}
