package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dao.IMobileDao;
import com.cg.mpa.dao.MobileDAOImpl;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public class MobileServiceImpl implements IMobileService {

	IMobileDao mobiledao=null;
	
	public MobileServiceImpl() {
		mobiledao=new MobileDAOImpl();
	}
	@Override
	public List<Mobile> getMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return mobiledao.getMobiles();
	}

	@Override
	public int insertPurchase(PurchaseDetails pdeDetails)
			throws MobileException {
		
		return mobiledao.insertPurchase(pdeDetails);
	}

}
