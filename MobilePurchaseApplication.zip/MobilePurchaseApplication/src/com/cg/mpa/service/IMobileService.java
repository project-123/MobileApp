package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public interface IMobileService {
	public List<Mobile> getMobiles() throws MobileException;
	public int insertPurchase(PurchaseDetails pdeDetails) throws MobileException;
	
}
