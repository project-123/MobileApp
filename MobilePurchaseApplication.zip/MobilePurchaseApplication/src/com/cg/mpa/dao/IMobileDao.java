package com.cg.mpa.dao;

import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;

public interface IMobileDao {

	
	public List<Mobile> getMobiles() throws MobileException;
	public int insertPurchase(PurchaseDetails pdeDetails) throws MobileException;
	
}
