package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.util.DBUtil;

public class MobileDAOImpl implements IMobileDao {

	Connection con;
	@Override
	public List<Mobile> getMobiles() throws MobileException {
		List<Mobile> mlist;
		String sql="Select * from mobiles";
		mlist = new ArrayList<>();
		con=DBUtil.getConnection();
		try {
			
			Statement st=con.createStatement();
			ResultSet res=st.executeQuery(sql);
			while(res.next())
			{
				Mobile m=new Mobile();
				m.setMobileid(res.getInt(1));
				m.setName(res.getString(2));
				m.setPrice(res.getDouble(3));
				m.setQuantity(res.getInt(4));
				
				mlist.add(m);
			
			}
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching mobile data "+e.getMessage());
		}
		
		
		return mlist;
	}

	private int fetchPurchaseId() throws MobileException
	{
		String sql="Select seq_purchaseid.NEXTVAL from dual";
		int pid;
		con=DBUtil.getConnection();
		try
		{
			Statement st=con.createStatement();
			ResultSet res=st.executeQuery(sql);
			res.next();
			pid=res.getInt(1);
		}
		catch(SQLException e)
		{
			throw new MobileException("Problem in fetching the purchase id"+e.getMessage());
			
		}
		return pid;
	}
	@Override
	public int insertPurchase(PurchaseDetails pdeDetails) throws MobileException {
		String sql="Insert into purchasedetails values(?,?,?,?,?,?)";
		pdeDetails.setPurchaseId(fetchPurchaseId());;
		con=DBUtil.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, pdeDetails.getPurchaseId());
			pst.setString(2, pdeDetails.getCname());
			pst.setString(3, pdeDetails.getMailid());
			pst.setString(4, pdeDetails.getPhoneno());
			pst.setDate(5, Date.valueOf(pdeDetails.getPurchaseDate()));
			pst.setInt(6, pdeDetails.getMobileid());
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new MobileException("Problem in inserting details"+e.getMessage());
		}
		
		return pdeDetails.getPurchaseId();
	}

}
