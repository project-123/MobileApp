package com.cg.mpa.dto;

import java.time.LocalDate;

public class PurchaseDetails {

	private int purchaseId;
	private String cname;
	private String mailid;
	private String phoneno;
	private LocalDate purchaseDate;
	private int mobileid;
	public PurchaseDetails() {
		super();
	}
	
	
	public PurchaseDetails(int purchaseId, String cname, String mailid,
			String phoneno, LocalDate purchaseDate, int mobileid) {
		super();
		this.purchaseId = purchaseId;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.purchaseDate = purchaseDate;
		this.mobileid = mobileid;
	}
	
	
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	
	
}
