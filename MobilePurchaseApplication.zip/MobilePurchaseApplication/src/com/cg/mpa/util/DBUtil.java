package com.cg.mpa.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



public class DBUtil {
	public static Connection getConnection()
	{
		InitialContext ic;
		Connection con=null;
		DataSource ds;
		/*		
		OracleDataSource ods=new OracleDataSource();
		ods.setUser("Labg103trg1");
		ods.setPassword("labg103oracle");
		ods.setDriverType("thin");
		ods.setNetworkProtocol("tcp");
		ods.setURL("jdbc:oracle:thin:@10.125.6.62:1521:orcl11g");
		return ods.getConnection();*/

		try 
		{
			if(con==null)
			{
				ic=new InitialContext();
				ds=(DataSource)ic.lookup("java:/jdbc/OracleDS");
				con= ds.getConnection();
				return con;
			}
			else
			{
				return con;
			}


		}
		catch(Exception e)
		{

		}
		return con;
	}
}



