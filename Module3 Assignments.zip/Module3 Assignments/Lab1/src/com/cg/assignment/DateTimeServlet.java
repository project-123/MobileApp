package com.cg.assignment;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.TimeZone;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DateTime
 */
@WebServlet(name = "DateTimeName", urlPatterns = { "/DateTimeMap" })
public class DateTimeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DateTimeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*PrintWriter pw=response.getWriter();
		Date today=new Date(18);
		 pw.println("date is");
		 pw.println(today);
		DateTimeServlet today=new DateTimeServlet();
		pw.println("date is");
		 pw.println(today);*/
		String now = new Date().toString();

	      // set content type to HTML
	      response.setContentType("text/html");

	      // print formatted information
	      PrintWriter out = response.getWriter();

	      String title = "Date Servlet";
	      out.println("<html><head><title>");
	      out.println(title);
	      out.println("</title></head><body><h1>");
	      out.print(title);
	      out.println("</h1><p>The current time is: ");
	      out.println(now);
	      out.println("</p></body></html>");

	      out.close();
	}

}
