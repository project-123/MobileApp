package com.cg.pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.User;

@WebServlet("/DisplayAllUsers")
public class DisplayAllUsers extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

    public DisplayAllUsers() 
    {
        super();
    }

	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter() ;
		ArrayList<User> users = (ArrayList) request.getAttribute("userlist") ;
		out.println("<table border='1'>");
		for(User user : users)
		{
			out.println("<tr>");
			out.println("<td>"+user.getFirstname()+"</td>");
			out.println("<td>"+user.getLastname()+"</td>");
			out.println("<td>"+user.getPassword()+"</td>");
			out.println("<td>"+user.getGender()+"</td>");
			out.println("<td>"+user.getSkillset()+"</td>");
			out.println("<td>"+user.getCity()+"</td>");
			out.println("</tr>");
		}
		
		out.println("</table>");
	}

}
