package com.cg.exception;

import com.cg.bean.User;

public class UserException extends RuntimeException
{
	
}
