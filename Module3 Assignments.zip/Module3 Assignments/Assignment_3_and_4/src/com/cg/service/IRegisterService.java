package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.User;

public interface IRegisterService 
{
	public int addUser(User user);
	public ArrayList<User> getAllUsers() ;
}
