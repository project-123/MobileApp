package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.User;
import com.cg.dao.IRegisterDAO;
import com.cg.dao.RegisterDAOImpl;

public class RegisterServiceImpl implements IRegisterService 
{
	IRegisterDAO registerDAO ;
	public RegisterServiceImpl() 
	{
		registerDAO = new RegisterDAOImpl() ; 
	}
	@Override
	public int addUser(User user) 
	{
		return registerDAO.addUser(user);
	}
	@Override
	public ArrayList<User> getAllUsers() 
	{
		return registerDAO.getAllUsers();
	}

}
