package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.User;
import com.cg.util.DBUtil;

public class RegisterDAOImpl implements IRegisterDAO 
{
	Connection con ;
	Statement stm ;
	PreparedStatement pstm ;
	ResultSet res ;
	@Override
	public int addUser(User user)
	{
		int id = 0 ;
		try
		{
			con = DBUtil.getConnection() ;
			String query = 
					"insert into REGISTEREDUSERS values(?,?,?,?,?,?)";
			
			pstm = con.prepareStatement(query) ;
			pstm.setString(1, user.getFirstname());
			pstm.setString(2, user.getLastname());
			pstm.setString(3, user.getPassword());
			pstm.setString(4, user.getGender());
			pstm.setString(5, user.getSkillset());
			pstm.setString(6, user.getCity());
			
			id=pstm.executeUpdate() ;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				pstm.close();
				con.close();
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			
		}
		
		return id ;
	}
	@Override
	public ArrayList<User> getAllUsers() 
	{
		ArrayList<User> users = new ArrayList<User>() ;
		try
		{
			con = DBUtil.getConnection() ;
			stm = con.createStatement() ;
			res = stm.executeQuery("select * from registeredusers") ;
			while(res.next())
			{
				User user = new User(res.getString(1),
						res.getString(2),
						res.getString(3),
						res.getString(4),
						res.getString(5),
						res.getString(6)) ;
				
				users.add(user);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				pstm.close();
				con.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return users ;
	}

}
