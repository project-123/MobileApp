CREATE TABLE RegisteredUsers 
( 
	firstname VARCHAR2 (20), 
	lastname VARCHAR2 (30),
	password VARCHAR2 (12) UNIQUE,
	gender varchar2(5),
	skillset VARCHAR2 (40),
	city VARCHAR2 (12)
);  

drop  table RegisterdUsers ;
select * from REGISTEREDUSERS ;