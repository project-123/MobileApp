package com.cg.lab2_1;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServletMap")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String un = request.getParameter("txtnam");

		String pw = request.getParameter("txtpwd");

		String mime = request.getContentType();

		System.out.println("The Mime Type Is "+mime);

		Locale locale = request.getLocale();

		System.out.println("The Locale Setting Is "+locale);

		long l = request.getContentLengthLong();

		System.out.println("The Data Transferred In Bytes Is "+l);

		if(un.equalsIgnoreCase("Aakash") && pw.equalsIgnoreCase("CG"))

		{

		response.sendRedirect("/Lab2/Success.html");

		}

		else

		{

		response.sendRedirect("/Lab2/failure.html");

		}
	}

}
