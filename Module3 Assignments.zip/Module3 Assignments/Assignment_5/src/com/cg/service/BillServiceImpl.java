package com.cg.service;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumer;
import com.cg.dao.BillDAOImpl;
import com.cg.dao.IBillDAO;

public class BillServiceImpl implements IBillService 
{

	IBillDAO billDAO ;
	public BillServiceImpl() 
	{
		billDAO = new BillDAOImpl() ;
	}
	@Override
	public boolean isCustomerExist(int consumer_num) 
	{
		return billDAO.isCustomerExist(consumer_num);
	}

	@Override
	public Consumer getConsumerDetails(int consumer_num) 
	{
		return billDAO.getConsumerDetails(consumer_num);
	}

	@Override
	public BillDetails addBillDetails(BillDetails billDetails) 
	{
		return billDAO.addBillDetails(billDetails);
	}

}
