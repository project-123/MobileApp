package com.cg.pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Consumer;
import com.cg.service.BillServiceImpl;
import com.cg.service.IBillService;

@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	IBillService billService ;
    public ValidateServlet() 
    {
        super();
        billService = new BillServiceImpl() ;
    }

	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	public void destroy()
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String consumerNum = (String) request.getAttribute("conNum") ;
		//String lastMR = (String) request.getAttribute("lastMR") ;
		//String currentMR = (String) request.getAttribute("currentMR") ;
		
		int consNum = Integer.parseInt(consumerNum) ;
		if(billService.isCustomerExist(consNum))
		{
			Consumer consumer = billService.getConsumerDetails(consNum) ;
		
			if(consumer != null )
			{
				RequestDispatcher rdSucc = request.getRequestDispatcher("/CalculateBill") ;
				rdSucc.forward(request, response);
			}
		}
		else
		{
			PrintWriter out = response.getWriter() ;
			out.println("Register");
		}
	}

}
