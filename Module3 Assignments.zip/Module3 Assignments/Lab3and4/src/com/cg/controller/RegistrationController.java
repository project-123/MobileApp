package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.User;
import com.cg.service.IRegisterService;
import com.cg.service.RegisterServiceImpl;

@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IRegisterService register ;
	ServletConfig conf ;
    public RegistrationController() 
    {
        super();
    }


	public void init(ServletConfig config) throws ServletException 
	{
		conf = config ;
	}

	public void destroy()
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		register = new RegisterServiceImpl();
		String action = request.getParameter("action") ;
		
		if(action.equals("RegisterUser"))
		{
			String firstname = request.getParameter("txtFName") ;
			String lastname = request.getParameter("txtLName") ;
			String password = request.getParameter("txtPass") ;
		    String gender = request.getParameter("gender") ;
			String skill[] = request.getParameterValues("skill") ;
			String city = request.getParameter("city") ;
			System.out.println(skill);
			String skills=null;
			for(int i=1;i<skill.length;i++)
			{
				skills=skill[0]+","+skill[i];
			}
	
				User user = new User(firstname, lastname, password, gender, skills, city);
			int id = register.addUser(user) ;
			
			if(id==1)
			{
				ArrayList<User> users = register.getAllUsers();
				request.setAttribute("userlist", users);
				
				RequestDispatcher rd = request.getRequestDispatcher("/DisplayAllUsers") ;
				rd.forward(request, response);
				//response.sendRedirect("/Assignment3/Success.html");
			}
			else
			{
				response.sendRedirect("/Assignment3/Failure.html");
			}
		}
	}

}
