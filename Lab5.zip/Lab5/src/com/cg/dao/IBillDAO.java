package com.cg.dao;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumer;

public interface IBillDAO 
{
	public boolean isCustomerExist( int consumer_num ) ;
	public Consumer getConsumerDetails( int consumer_num ) ;
	public BillDetails addBillDetails( BillDetails billDetails ) ;
}
