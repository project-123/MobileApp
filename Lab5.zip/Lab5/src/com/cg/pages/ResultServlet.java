package com.cg.pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.BillDetails;
import com.cg.bean.Consumer;

/**
 * Servlet implementation class ResultServlet
 */
@WebServlet("/ResultServlet")
public class ResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ResultServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BillDetails billdetails = (BillDetails) request.getAttribute("billInfo");

		Consumer consumer = (Consumer) request.getAttribute("consumerInfo");

		String cons = consumer.getConsumer_name();

		int consnum = consumer.getConsumer_num();

		int uc = billdetails.getUnitConsumed();

		double na = billdetails.getNetamount();

		PrintWriter pw = response.getWriter();

		pw.println("<b>Welcome - "+cons+"</b>");

		pw.println("<br/>");

		pw.println("<h1> Electricity Bill For Consumer Number - "+consnum+" Is :<br/>");

		pw.println("<br/>");

		pw.println("Units Consumed :: "+uc+"<br/>");

		pw.println("Net Amount :: "+na);
	}

}
