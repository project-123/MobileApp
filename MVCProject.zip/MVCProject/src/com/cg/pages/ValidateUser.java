package com.cg.pages;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.User;
import com.cg.service.IUserService;
import com.cg.service.UserServiceImpl;


@WebServlet("/ValidateUser")
public class ValidateUser extends HttpServlet {
	IUserService userService=null;
	private static final long serialVersionUID = 1L;
       
   
    public ValidateUser() 
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException
	{
		
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		userService=new UserServiceImpl();
		User temp=(User)request.getAttribute("LogDetailsObj");
		if(userService.isUserExist(temp.getUsername()))
		{
			User userDetails=userService.getUserDetails(temp.getUsername());
			if(temp.getPassword().equalsIgnoreCase(userDetails.getPassword()))
			{
				RequestDispatcher rdSuccess=request.getRequestDispatcher("/SuccessServlet");
				rdSuccess.forward(request, response);
			}
			else
			{
				RequestDispatcher rdFailure=request.getRequestDispatcher("/FailureServlet");
				rdFailure.forward(request, response);
			}
		}
		else
		{
			RequestDispatcher rdNotFound=request.getRequestDispatcher("/RegisterationServlet");
			rdNotFound.forward(request, response);
		}
		
		
		
	}

}
