package com.cg.pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RegisterationServlet")
public class RegisterationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public RegisterationServlet() 
    {
        super();
      
    }

	
	public void init(ServletConfig config) throws ServletException
	{
		
	}

	
	public void destroy()
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter pw=response.getWriter();
		pw.println("<h1>Register Here</h1>");
		pw.println("<br/><h1>Add User</h1>");
		pw.println("<br/><form action='./ControllerServlet?action=InsertUser' method='post'");
		pw.println("<br/>UserName:<input type='text' name='txtUName'/>");
		pw.println("<br/>Password:<input type='password' name='txtPass'/>");
		pw.println("<br/><input type='submit' value='Add User'/>");
		pw.println("<br/></form>");
	
	
	}

}
