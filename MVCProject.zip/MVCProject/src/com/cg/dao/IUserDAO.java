package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.User;

public interface IUserDAO {

	public boolean isUserExist(String unm);
	
	public User getUserDetails(String un);

	public int insertUser(User user);

	public ArrayList<User> getAllUsers();
	
}
