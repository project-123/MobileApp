package com.cg.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.User;
import com.cg.util.DBUtil;

public class UserDAOImpl implements IUserDAO
{

	Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet res;
	
	@Override
	public boolean isUserExist(String unm) {
		boolean flag=false;
			try {
				con= DBUtil.getConnection();
				System.out.println(con);
				String selectQry="Select count(*) from cg_user where username=?";
				
					pst=con.prepareStatement(selectQry);
					pst.setString(1, unm);
					res=pst.executeQuery();
					res.next();
					int count=res.getInt(1);
					if(count==1)
					{
						flag=true;
					}
					else
					{
						System.out.println("*******"+res);
						flag=false;
					}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				
				try {
					con.close();
					res.close();
					pst.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return flag;
		
	}

	@Override
	public User getUserDetails(String un) {
		User usr=null;
		try 
		{
		con=DBUtil.getConnection();
		System.out.println("get user details ******con"+con);
		String selQry="Select * from cg_user where username=?";
		
			pst=con.prepareStatement(selQry);
			pst.setString(1, un);
			res=pst.executeQuery();
			res.next();
			usr=new User();
			usr.setUsername(res.getString(1));
			usr.setPassword(res.getString(2));
		} 
		catch (SQLException e)
		{
			
			e.printStackTrace();
		}
		finally
		{
			try {
				res.close();
				pst.close();
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		return usr;
	}

	@Override
	public int insertUser(User user) 
	{
		con=DBUtil.getConnection();
		String insquery="insert into cg_user values(?,?)";
		int dataInserted=0;
		try
		{
			pst=con.prepareStatement(insquery);
			pst.setString(1, user.getUsername());
			pst.setString(2, user.getPassword());
			dataInserted=pst.executeUpdate();
		} catch (SQLException e)
		{
			
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				e.printStackTrace();
			}
		}
		
		
		return dataInserted;
	}

	@Override
	public ArrayList<User> getAllUsers() {
		
		ArrayList<User> uList=new ArrayList<User>();
		con=DBUtil.getConnection();
		try {
			st=con.createStatement();
			res=st.executeQuery("Select * from cg_user");
			while(res.next())
			{
				User usr=new User(res.getString(1),res.getString(2));
				uList.add(usr);
			}
		} 
		catch (SQLException e)
		{
			
			e.printStackTrace();
		}
		finally
		{
			try
			{
				st.close();
				res.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				e.printStackTrace();
			}
		}
		return uList;
	}

}
