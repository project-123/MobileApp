package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.User;
import com.cg.dao.IUserDAO;
import com.cg.dao.UserDAOImpl;

public class UserServiceImpl implements IUserService
{

	IUserDAO userdao=null;
	
	public UserServiceImpl() {
		super();
		
		userdao=new UserDAOImpl();
	}

	@Override
	public boolean isUserExist(String unm) {
		// TODO Auto-generated method stub
		return userdao.isUserExist(unm);
	}

	@Override
	public User getUserDetails(String un) {
		// TODO Auto-generated method stub
		return userdao.getUserDetails(un);
	}

	@Override
	public int insertUser(User user) {
		// TODO Auto-generated method stub
		return userdao.insertUser(user);
	}

	@Override
	public ArrayList<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userdao.getAllUsers();
	}
	
	
	
	

}
