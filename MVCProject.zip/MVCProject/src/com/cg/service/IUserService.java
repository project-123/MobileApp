package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.User;

public interface IUserService 
{
	public boolean isUserExist(String unm);

	public User getUserDetails(String un);
	
	public int insertUser(User user);
	public ArrayList<User> getAllUsers();
}
