package com.cg.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.User;
import com.cg.service.IUserService;
import com.cg.service.UserServiceImpl;
import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;


@WebServlet(name="ControllerServlet",
urlPatterns={"/ControllerServlet"})
public class ControllerServlet extends HttpServlet {
	ServletConfig conf;
	IUserService userService=new UserServiceImpl();
	private static final long serialVersionUID = 1L;
       
   
    public ControllerServlet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		conf=config;
	}

	
	public void destroy()
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String action=request.getParameter("action");
		if(action!=null)
		{
			
			/****ShowLoginPage************/
			if(action.equals("ShowLoginPage"))
			{
				RequestDispatcher rdLog=request.getRequestDispatcher("/Login.html");
				rdLog.forward(request, response);
			}
			
			/****ValidateUser***********/
			
			if(action.equals("ValidateUser"))
			{
				String un=request.getParameter("txtUName");
				String pw=request.getParameter("txtPass");
				User log=new User(un,pw);
				request.setAttribute("LogDetailsObj", log);
				RequestDispatcher rdVal=request.getRequestDispatcher("/ValidateUser");
				rdVal.forward(request, response);
			}
			
			/**********Insert User********/
			if(action.equals("InsertUser"))
			{
				String un=request.getParameter("txtUName");
				String pw=request.getParameter("txtPass");
				int dataIns=userService.insertUser(new User(un,pw));
				if(dataIns==1)
				{
					ArrayList<User> uList=userService.getAllUsers();
					request.setAttribute("UListObj", uList);
					RequestDispatcher rdIns=request.getRequestDispatcher("/DisplayAllUserServlet");
					rdIns.forward(request, response);
				}
			}
			
		}
		else
		{
			PrintWriter pw=response.getWriter();
			pw.println("No Action Defined");
		}
	}

}
